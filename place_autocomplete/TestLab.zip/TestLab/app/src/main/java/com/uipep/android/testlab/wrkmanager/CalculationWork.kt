package com.uipep.android.testlab.wrkmanager

import android.content.Context

class CalculationWork(var context : Context)
package com.uipep.android.testlab.service;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

public class BuckysIntentService extends IntentService {

    public BuckysIntentService() {
        super("BuckysIntentService");
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("BuckysIntentService", "onStartCommand: ");
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        for (int i = 0; i <= 20; i++){
            try {
                Log.d("BuckysIntentService", "onHandleIntent: service was started " + Thread.currentThread().getName());
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                Log.d("BuckysIntentService", "Exception");
                e.printStackTrace();
            }

        }

        stopSelf();

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d("BuckysIntentService", "Bucky was killed");

    }
}
